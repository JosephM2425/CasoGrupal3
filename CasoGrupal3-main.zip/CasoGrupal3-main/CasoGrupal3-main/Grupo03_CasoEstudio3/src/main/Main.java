package main;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import constructores.ClienteAbstractBuilder;
import constructores.ClienteBuilder;
import objetos.Cliente;
import objetos.Nave;

public class Main {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        // Crear el Builder del cliente
        ClienteAbstractBuilder clienteBuilder = new ClienteBuilder();

        // Ingresar información del cliente
        System.out.println("Ingrese los datos del cliente:");
        clienteBuilder.agregarNumeroTelefonico(readLine(reader, "Número telefónico: "));
        clienteBuilder.agregarNombre(readLine(reader, "Nombre: "));
        clienteBuilder.agregarApellido1(readLine(reader, "Apellido 1: "));
        clienteBuilder.agregarApellido2(readLine(reader, "Apellido 2: "));

        // Agregar lista de naves
        System.out.println("Ingrese la información de las naves (Ingrese '0' para dejar de agregar naves):");
        agregarNaves(clienteBuilder, reader);

        // Obtener el objeto Cliente construido
        Cliente cliente = clienteBuilder.getCliente();

        // Mostrar los datos ingresados
        System.out.println("Datos del cliente:");
        System.out.println("Número telefónico: " + cliente.getNumeroTelefonico());
        System.out.println("Nombre: " + cliente.getNombre());
        System.out.println("Apellido 1: " + cliente.getApellido1());
        System.out.println("Apellido 2: " + cliente.getApellido2());
        System.out.println("Lista de naves: " + cliente.getListaNaves());
    }


    private static void agregarNaves(ClienteAbstractBuilder clienteBuilder, BufferedReader reader) {
        while (true) {
            String categoria = readLine(reader, "Categoría: ");
            if (categoria.equals("0")) {
                break;
            }
            String marca = readLine(reader, "Marca: ");
            String modelo = readLine(reader, "Modelo: ");
            int anio = Integer.parseInt(readLine(reader, "Año: "));
            String codigoIdentificacion = readLine(reader, "Código de identificación: ");
            String color = readLine(reader, "Color: ");

            // Crear la nave y agregarla al Builder del cliente
            Nave nave = new Nave(categoria, marca, modelo, anio, codigoIdentificacion, color);
            clienteBuilder.agregarListaNaves();
        }
    }

    private static String readLine(BufferedReader reader, String prompt) {
        try {
            System.out.print(prompt);
            return reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }
}